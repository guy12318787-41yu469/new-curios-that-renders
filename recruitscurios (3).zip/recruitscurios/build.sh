#!/usr/bin/env bash
# Builds the mod jar. Needs: JDK 17 and Gradle 8.x on PATH (or use the GitHub Actions workflow).
set -e
command -v gradle >/dev/null || { echo "Gradle not found. Install Gradle 8.x (https://gradle.org/install/)"; exit 1; }
gradle build
echo; echo "Done. Your jar:"; ls build/libs/*.jar
