package com.example.recruitscurios.client;

import com.example.recruitscurios.SyncRecruitCuriosPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import top.theillusivec4.curios.api.CuriosApi;
import top.theillusivec4.curios.api.type.inventory.ICurioStacksHandler;

import java.util.Map;

/** Client-only: writes the synced stacks into the client copy of the recruit's Curios inventory. */
public final class ClientSync {
    private ClientSync() {}

    public static void apply(SyncRecruitCuriosPacket msg) {
        if (Minecraft.getInstance().level == null) return;
        Entity e = Minecraft.getInstance().level.getEntity(msg.getEntityId());
        if (!(e instanceof LivingEntity living)) return;

        CuriosApi.getCuriosInventory(living).ifPresent(handler -> {
            Map<String, ICurioStacksHandler> map = handler.getCurios();
            for (SyncRecruitCuriosPacket.Entry en : msg.getEntries()) {
                ICurioStacksHandler sh = map.get(en.slotId());
                if (sh == null || en.index() >= sh.getSlots()) continue;
                sh.getStacks().setStackInSlot(en.index(), en.stack());
            }
        });
    }
}
