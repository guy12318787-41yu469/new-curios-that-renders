package com.example.recruitscurios;

import com.example.recruitscurios.client.ClientSync;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** Server -> client: full snapshot of a recruit's accessory slots, so the Curios render layer can draw them. */
public class SyncRecruitCuriosPacket {
    public record Entry(String slotId, int index, ItemStack stack) {}

    private final int entityId;
    private final List<Entry> entries;

    public SyncRecruitCuriosPacket(int entityId, List<Entry> entries) {
        this.entityId = entityId;
        this.entries = entries;
    }

    public int getEntityId() { return entityId; }
    public List<Entry> getEntries() { return entries; }

    public static void encode(SyncRecruitCuriosPacket msg, FriendlyByteBuf buf) {
        buf.writeVarInt(msg.entityId);
        buf.writeVarInt(msg.entries.size());
        for (Entry e : msg.entries) {
            buf.writeUtf(e.slotId());
            buf.writeVarInt(e.index());
            buf.writeItem(e.stack());
        }
    }

    public static SyncRecruitCuriosPacket decode(FriendlyByteBuf buf) {
        int id = buf.readVarInt();
        int n = buf.readVarInt();
        List<Entry> list = new ArrayList<>(n);
        for (int i = 0; i < n; i++) list.add(new Entry(buf.readUtf(), buf.readVarInt(), buf.readItem()));
        return new SyncRecruitCuriosPacket(id, list);
    }

    public static void handle(SyncRecruitCuriosPacket msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientSync.apply(msg)));
        ctx.setPacketHandled(true);
    }
}
