package com.example.recruitscurios;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkHooks;

import java.util.function.Supplier;

/** Client -> server: "open the accessory menu for this recruit". Everything is re-validated server-side. */
public class OpenCuriosPacket {
    private final int entityId;

    public OpenCuriosPacket(int entityId) { this.entityId = entityId; }

    public static void encode(OpenCuriosPacket msg, FriendlyByteBuf buf) { buf.writeVarInt(msg.entityId); }

    public static OpenCuriosPacket decode(FriendlyByteBuf buf) { return new OpenCuriosPacket(buf.readVarInt()); }

    public static void handle(OpenCuriosPacket msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player == null) return;

            Entity e = player.level().getEntity(msg.entityId);
            if (!(e instanceof LivingEntity recruit) || !RecruitsReflect.isRecruit(recruit)) return;
            if (player.distanceToSqr(recruit) > 64.0) return;
            if (!RecruitsReflect.isOwnedBy(recruit, player)) {
                player.displayClientMessage(Component.literal("You can only edit your own recruits."), true);
                return;
            }

            NetworkHooks.openScreen(player,
                    new SimpleMenuProvider((id, inv, p) -> new RecruitCuriosMenu(id, inv, recruit),
                            Component.literal(recruit.getDisplayName().getString() + " - Accessories")),
                    buf -> buf.writeVarInt(recruit.getId()));
        });
        ctx.setPacketHandled(true);
    }
}
