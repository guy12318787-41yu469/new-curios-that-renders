package com.example.recruitscurios;

import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import top.theillusivec4.curios.api.CuriosApi;
import top.theillusivec4.curios.api.SlotContext;
import top.theillusivec4.curios.api.type.inventory.ICurioStacksHandler;
import top.theillusivec4.curios.api.type.inventory.IDynamicStackHandler;

import java.util.Map;
import java.util.TreeMap;

/** Quick equip: right-click an owned recruit while holding a Curios item. */
public class RecruitInteractHandler {

    @SubscribeEvent(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent.EntityInteract event) {
        if (event.getLevel().isClientSide()) return;
        if (event.getHand() != InteractionHand.MAIN_HAND) return;
        if (!(event.getTarget() instanceof LivingEntity target)) return;
        if (!RecruitsReflect.isRecruit(target)) return;

        Player player = event.getEntity();
        ItemStack held = player.getItemInHand(InteractionHand.MAIN_HAND);
        if (held.isEmpty()) return;

        boolean[] equipped = { false };
        boolean[] denied = { false };
        CuriosApi.getCuriosInventory(target).ifPresent(handler -> {
            for (Map.Entry<String, ICurioStacksHandler> entry : new TreeMap<>(handler.getCurios()).entrySet()) {
                String slotId = entry.getKey();
                ICurioStacksHandler slotHandler = entry.getValue();
                IDynamicStackHandler stacks = slotHandler.getStacks();

                for (int i = 0; i < slotHandler.getSlots(); i++) {
                    if (!stacks.getStackInSlot(i).isEmpty()) continue;

                    SlotContext ctx = new SlotContext(slotId, target, i, false, true);
                    if (!CuriosApi.isStackValid(ctx, held)) continue;

                    if (!RecruitsReflect.isOwnedBy(target, player)) {
                        denied[0] = true;
                        return;
                    }

                    ItemStack toEquip = player.getAbilities().instabuild ? held.copyWithCount(1) : held.split(1);
                    stacks.setStackInSlot(i, toEquip);
                    equipped[0] = true;
                    return;
                }
            }
        });

        if (denied[0]) {
            player.displayClientMessage(Component.literal("You can only equip your own recruits."), true);
            event.setCanceled(true);
            event.setCancellationResult(InteractionResult.FAIL);
            return;
        }

        if (equipped[0]) {
            RecruitCuriosSync.syncTracking(target);
            target.level().playSound(null, target.blockPosition(), SoundEvents.ARMOR_EQUIP_GENERIC,
                    SoundSource.NEUTRAL, 1.0F, 1.0F);
            event.setCanceled(true);
            event.setCancellationResult(InteractionResult.SUCCESS);
        }
    }

    /** When a player starts seeing a recruit, send them its accessories so they render. */
    @SubscribeEvent
    public void onStartTracking(PlayerEvent.StartTracking event) {
        if (event.getEntity() instanceof ServerPlayer sp
                && event.getTarget() instanceof LivingEntity le
                && RecruitsReflect.isRecruit(le)) {
            RecruitCuriosSync.syncTo(sp, le);
        }
    }
}
