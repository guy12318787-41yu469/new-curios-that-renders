package com.example.recruitscurios;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.UUID;

/**
 * Talks to Villager Recruits by name so this mod needs no compile-time dependency on it.
 * Methods verified in Recruits 1.15.2: AbstractRecruitEntity.getOwnerUUID() (public, returns UUID),
 * RecruitInventoryMenu.getRecruit() (returns AbstractRecruitEntity). Everything fails closed.
 */
public final class RecruitsReflect {
    private RecruitsReflect() {}

    public static boolean isRecruit(Entity e) {
        ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(e.getType());
        return id != null && id.getNamespace().equals("recruits");
    }

    public static UUID getOwner(Entity e) {
        try {
            Object o = e.getClass().getMethod("getOwnerUUID").invoke(e);
            return o instanceof UUID u ? u : null;
        } catch (ReflectiveOperationException | RuntimeException ex) {
            return null;
        }
    }

    public static boolean isOwnedBy(Entity recruit, Player player) {
        UUID owner = getOwner(recruit);
        return owner != null && owner.equals(player.getUUID());
    }

    /** Client side: pull the recruit out of Recruits' own inventory menu. */
    public static LivingEntity recruitFromMenu(AbstractContainerMenu menu) {
        try {
            Object o = menu.getClass().getMethod("getRecruit").invoke(menu);
            return o instanceof LivingEntity le ? le : null;
        } catch (ReflectiveOperationException | RuntimeException ex) {
            return null;
        }
    }
}
