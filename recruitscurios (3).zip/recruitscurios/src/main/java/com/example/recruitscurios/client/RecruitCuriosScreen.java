package com.example.recruitscurios.client;

import com.example.recruitscurios.RecruitCuriosMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;

public class RecruitCuriosScreen extends AbstractContainerScreen<RecruitCuriosMenu> {

    public RecruitCuriosScreen(RecruitCuriosMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
        this.imageWidth = 176;
        this.imageHeight = menu.getImageHeight();
        this.inventoryLabelY = menu.getPlayerInvY() - 11;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g);
        super.render(g, mouseX, mouseY, partialTick);
        this.renderTooltip(g, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        int x = this.leftPos, y = this.topPos;
        // Panel
        g.fill(x, y, x + imageWidth, y + imageHeight, 0xFF000000);
        g.fill(x + 1, y + 1, x + imageWidth - 1, y + imageHeight - 1, 0xFFC6C6C6);
        // Slot frames
        for (Slot s : this.menu.slots) {
            int sx = x + s.x, sy = y + s.y;
            g.fill(sx - 1, sy - 1, sx + 17, sy + 17, 0xFF373737);
            g.fill(sx, sy, sx + 18, sy + 18, 0xFFFFFFFF);
            g.fill(sx, sy, sx + 17, sy + 17, 0xFF8B8B8B);
        }
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        super.renderLabels(g, mouseX, mouseY);
        if (this.menu.getCurioSlotCount() == 0) {
            g.drawString(this.font, "No accessory slots found", 8, 20, 0x404040, false);
        }
    }

    @Override
    protected void renderTooltip(GuiGraphics g, int x, int y) {
        if (this.hoveredSlot instanceof RecruitCuriosMenu.CurioSlot cs
                && !cs.hasItem() && this.menu.getCarried().isEmpty()) {
            g.renderTooltip(this.font, Component.translatable("curios.identifier." + cs.identifier), x, y);
        } else {
            super.renderTooltip(g, x, y);
        }
    }
}
