package com.example.recruitscurios;

import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.Optional;

public class Net {
    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(RecruitsCurios.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public static void register() {
        CHANNEL.registerMessage(0, OpenCuriosPacket.class,
                OpenCuriosPacket::encode, OpenCuriosPacket::decode, OpenCuriosPacket::handle);
        CHANNEL.registerMessage(1, SyncRecruitCuriosPacket.class,
                SyncRecruitCuriosPacket::encode, SyncRecruitCuriosPacket::decode, SyncRecruitCuriosPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
    }
}
