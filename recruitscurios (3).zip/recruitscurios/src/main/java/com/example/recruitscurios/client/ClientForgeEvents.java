package com.example.recruitscurios.client;

import com.example.recruitscurios.Net;
import com.example.recruitscurios.OpenCuriosPacket;
import com.example.recruitscurios.RecruitsCurios;
import com.example.recruitscurios.RecruitsReflect;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Adds an "Accessories" button to Villager Recruits' inventory screen. */
@Mod.EventBusSubscriber(modid = RecruitsCurios.MODID, value = Dist.CLIENT)
public class ClientForgeEvents {

    // Button placement relative to the Recruits panel. Tweak if it overlaps something on your setup.
    private static final int BTN_W = 72, BTN_H = 18;

    @SubscribeEvent
    public static void onScreenInit(ScreenEvent.Init.Post event) {
        if (!(event.getScreen() instanceof AbstractContainerScreen<?> screen)) return;
        if (!screen.getClass().getName().equals("com.talhanation.recruits.client.gui.RecruitInventoryScreen")) return;

        LivingEntity recruit = RecruitsReflect.recruitFromMenu(screen.getMenu());
        if (recruit == null) return;

        int x = screen.getGuiLeft() + screen.getXSize() - BTN_W;
        int y = screen.getGuiTop() - BTN_H - 2;
        int id = recruit.getId();

        Button button = Button.builder(Component.literal("Accessories"),
                        b -> Net.CHANNEL.sendToServer(new OpenCuriosPacket(id)))
                .bounds(x, y, BTN_W, BTN_H)
                .build();
        event.addListener(button);
    }
}
