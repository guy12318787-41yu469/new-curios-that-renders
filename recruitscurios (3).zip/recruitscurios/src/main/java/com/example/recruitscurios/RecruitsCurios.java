package com.example.recruitscurios;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(RecruitsCurios.MODID)
public class RecruitsCurios {
    public static final String MODID = "recruitscurios";

    public RecruitsCurios() {
        ModMenus.MENUS.register(FMLJavaModLoadingContext.get().getModEventBus());
        Net.register();
        MinecraftForge.EVENT_BUS.register(new RecruitInteractHandler());
    }
}
