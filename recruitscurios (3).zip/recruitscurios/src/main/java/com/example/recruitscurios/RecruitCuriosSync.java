package com.example.recruitscurios;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.network.PacketDistributor;
import top.theillusivec4.curios.api.CuriosApi;
import top.theillusivec4.curios.api.type.inventory.ICurioStacksHandler;
import top.theillusivec4.curios.api.type.inventory.IDynamicStackHandler;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Server-side helpers that push a recruit's accessory contents to clients. */
public final class RecruitCuriosSync {
    private RecruitCuriosSync() {}

    public static SyncRecruitCuriosPacket snapshot(LivingEntity recruit) {
        List<SyncRecruitCuriosPacket.Entry> list = new ArrayList<>();
        CuriosApi.getCuriosInventory(recruit).ifPresent(handler -> {
            for (Map.Entry<String, ICurioStacksHandler> e : handler.getCurios().entrySet()) {
                IDynamicStackHandler stacks = e.getValue().getStacks();
                for (int i = 0; i < e.getValue().getSlots(); i++) {
                    list.add(new SyncRecruitCuriosPacket.Entry(e.getKey(), i, stacks.getStackInSlot(i).copy()));
                }
            }
        });
        return new SyncRecruitCuriosPacket(recruit.getId(), list);
    }

    /** To everyone currently tracking the recruit. */
    public static void syncTracking(LivingEntity recruit) {
        if (recruit.level().isClientSide()) return;
        Net.CHANNEL.send(PacketDistributor.TRACKING_ENTITY.with(() -> recruit), snapshot(recruit));
    }

    /** To one player (used when they start tracking the recruit). */
    public static void syncTo(ServerPlayer player, LivingEntity recruit) {
        Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), snapshot(recruit));
    }
}
