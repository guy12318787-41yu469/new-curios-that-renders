package com.example.recruitscurios;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.items.SlotItemHandler;
import top.theillusivec4.curios.api.CuriosApi;
import top.theillusivec4.curios.api.SlotContext;
import top.theillusivec4.curios.api.type.inventory.ICurioStacksHandler;
import top.theillusivec4.curios.api.type.inventory.IDynamicStackHandler;

import java.util.Map;
import java.util.TreeMap;

public class RecruitCuriosMenu extends AbstractContainerMenu {
    private static final int COLS = 9;

    private final LivingEntity recruit;
    private int curioSlotCount = 0;
    private int rows = 1;

    /** Client-side constructor (called by the menu type with the packet buffer). */
    public RecruitCuriosMenu(int id, Inventory inv, FriendlyByteBuf buf) {
        this(id, inv, resolve(inv.player, buf.readVarInt()));
    }

    private static LivingEntity resolve(Player player, int entityId) {
        Entity e = player.level().getEntity(entityId);
        return e instanceof LivingEntity le ? le : null;
    }

    public RecruitCuriosMenu(int id, Inventory inv, LivingEntity recruit) {
        super(ModMenus.RECRUIT_CURIOS.get(), id);
        this.recruit = recruit;

        if (recruit != null) {
            // TreeMap => identical slot order on client and server.
            CuriosApi.getCuriosInventory(recruit).ifPresent(handler -> {
                for (Map.Entry<String, ICurioStacksHandler> entry : new TreeMap<>(handler.getCurios()).entrySet()) {
                    String slotId = entry.getKey();
                    ICurioStacksHandler slotHandler = entry.getValue();
                    IDynamicStackHandler stacks = slotHandler.getStacks();
                    for (int i = 0; i < slotHandler.getSlots(); i++) {
                        int col = curioSlotCount % COLS;
                        int row = curioSlotCount / COLS;
                        addSlot(new CurioSlot(recruit, slotId, stacks, i, 8 + col * 18, 18 + row * 18));
                        curioSlotCount++;
                    }
                }
            });
        }
        rows = Math.max(1, (curioSlotCount + COLS - 1) / COLS);

        int invY = getPlayerInvY();
        for (int r = 0; r < 3; r++)
            for (int c = 0; c < 9; c++)
                addSlot(new Slot(inv, c + r * 9 + 9, 8 + c * 18, invY + r * 18));
        for (int c = 0; c < 9; c++)
            addSlot(new Slot(inv, c, 8 + c * 18, invY + 58));
    }

    public int getPlayerInvY() { return 32 + rows * 18; }
    public int getImageHeight() { return getPlayerInvY() + 83; }
    public int getCurioSlotCount() { return curioSlotCount; }
    public LivingEntity getRecruit() { return recruit; }

    @Override
    public void removed(Player player) {
        super.removed(player);
        if (recruit != null && !player.level().isClientSide()) RecruitCuriosSync.syncTracking(recruit);
    }

    @Override
    public boolean stillValid(Player player) {
        if (recruit == null || !recruit.isAlive() || player.distanceToSqr(recruit) > 64.0) return false;
        return player.level().isClientSide() || RecruitsReflect.isOwnedBy(recruit, player);
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        Slot slot = slots.get(index);
        if (slot == null || !slot.hasItem()) return ItemStack.EMPTY;
        ItemStack stack = slot.getItem();
        ItemStack copy = stack.copy();

        if (index < curioSlotCount) {
            if (!moveItemStackTo(stack, curioSlotCount, slots.size(), true)) return ItemStack.EMPTY;
        } else if (!moveItemStackTo(stack, 0, curioSlotCount, false)) {
            return ItemStack.EMPTY;
        }

        if (stack.isEmpty()) slot.setByPlayer(ItemStack.EMPTY); else slot.setChanged();
        return copy;
    }

    /** A slot backed by the recruit's Curios inventory, validated against the recruit (not the player). */
    public static class CurioSlot extends SlotItemHandler {
        public final String identifier;
        private final LivingEntity owner;
        private final int index;

        public CurioSlot(LivingEntity owner, String identifier, IDynamicStackHandler handler, int index, int x, int y) {
            super(handler, index, x, y);
            this.owner = owner;
            this.identifier = identifier;
            this.index = index;
        }

        private SlotContext ctx() { return new SlotContext(identifier, owner, index, false, true); }

        @Override
        public void setChanged() {
            super.setChanged();
            if (!owner.level().isClientSide()) RecruitCuriosSync.syncTracking(owner);
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return !stack.isEmpty() && CuriosApi.isStackValid(ctx(), stack);
        }

        @Override
        public boolean mayPickup(Player player) {
            ItemStack stack = getItem();
            if (stack.isEmpty()) return false;
            SlotContext c = ctx();
            return CuriosApi.getCurio(stack).map(curio -> curio.canUnequip(c)).orElse(true);
        }
    }
}
