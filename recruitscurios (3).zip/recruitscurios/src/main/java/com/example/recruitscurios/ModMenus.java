package com.example.recruitscurios;

import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModMenus {
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(ForgeRegistries.MENU_TYPES, RecruitsCurios.MODID);

    public static final RegistryObject<MenuType<RecruitCuriosMenu>> RECRUIT_CURIOS =
            MENUS.register("recruit_curios", () -> IForgeMenuType.create(RecruitCuriosMenu::new));
}
