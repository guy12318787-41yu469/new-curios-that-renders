# Recruits Curios Compat (Forge 1.20.1)

Built against Villager Recruits 1.15.2 and Curios 5.14.1. Gives recruits Curios slots, an
"Accessories" button on the Recruits inventory screen, and right-click quick-equip. Owner only.

## Get the jar (pick one)
**A. GitHub (no local setup):** create a repo, upload this folder, open the Actions tab, run
"Build jar", download the `recruitscurios-jar` artifact. The jar is inside.

**B. Locally:** install JDK 17 and Gradle 8.x, then run `build.bat` (Windows) or `./build.sh`.
Jar appears in `build/libs/`. First build downloads Forge and takes several minutes.

Villager Recruits is NOT needed to build. Put the jar in `mods/` next to Curios and Recruits.

## Use
- Open a recruit's inventory, click **Accessories** (above the panel, top-right), drop items in slots.
- Shift-click moves items between your inventory and the slots.
- Or right-click a recruit holding a Curios item to quick-equip.

## Verified against your jars
Entity IDs, Curios API signatures, getOwnerUUID(), RecruitInventoryMenu.getRecruit().

## Not verified (untested, never compiled)
- Compile errors are possible; paste them back.
- Button position may overlap Recruits widgets: change BTN_W/BTN_H/x/y in ClientForgeEvents.
- Slot lists must match client/server; if Curios doesn't sync recruit slots to the client you'll see
  "No accessory slots found".
- Whether equipped attribute items apply to recruits.
