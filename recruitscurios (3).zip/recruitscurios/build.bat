@echo off
where gradle >nul 2>nul || (echo Gradle not found. Install Gradle 8.x from https://gradle.org/install/ & exit /b 1)
call gradle build || exit /b 1
echo.
echo Done. Your jar is in build\libs\
dir build\libs\*.jar
pause
